<? use Bitrix\Main\Localization\Loc;

if (!defined('B_PROLOG_INCLUDED') || B_PROLOG_INCLUDED !== true) {
	die();
} ?>
<script id="external-link-setting-info" type="text/html">
	<div class="disk-detail-sidebar-public-link-info" data-entity="external-link-info-text">{{buildText}}</div>
</script>